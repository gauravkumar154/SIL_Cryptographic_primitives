#!/usr/bin/env bash

# Install required packages using pip
pip3 install pwn
pip3 install pyaes
pip3 install cryptography
pip3 install hashlib
pip3 install pycryptoplus

# Ensure successful installation
# if [ $? -eq 0 ]; then
#     echo "Environment setup successful."
# else
#     echo "Error: Environment setup failed."
# fi
