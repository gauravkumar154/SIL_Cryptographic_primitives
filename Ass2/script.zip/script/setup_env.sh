#!/usr/bin/env bash

# Install packages

# pip3 install {package_name}
